namespace FacebookConnection
{
    public static class FacebookSettings
    {
        public static string AccessToken = @"INSERIR_AQUI_SEU_TOKEN";

        
    }
}